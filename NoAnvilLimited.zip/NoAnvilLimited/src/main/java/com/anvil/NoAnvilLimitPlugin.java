package com.anvil;

import java.util.Map;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.AnvilInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class NoAnvilLimitPlugin extends JavaPlugin implements Listener {

    private static final int MAX_REPAIR_COST = 39;

    @Override
    public void onEnable() {
         getServer().getPluginManager().registerEvents(this, this);
         getLogger().info("NoAnvilLimitPlugin включён!");
    }

    @Override
    public void onDisable() {
         getLogger().info("NoAnvilLimitPlugin выключён!");
    }

    @EventHandler
    public void onPrepareAnvil(PrepareAnvilEvent event) {
         AnvilInventory anvil = event.getInventory();
         ItemStack first = anvil.getItem(0);
         ItemStack second = anvil.getItem(1);

         // Если оба предмета – зачарованные книги, оставляем стандартное поведение
         if (isEnchantedBook(first) && isEnchantedBook(second)) {
              return;
         }

         // Если хотя бы один из предметов – зачарованная книга
         if (isEnchantedBook(first) || isEnchantedBook(second)) {
              if (event.getResult() != null) {
                   int cost = anvil.getRepairCost();
                   if (cost > MAX_REPAIR_COST) {
                         cost = MAX_REPAIR_COST;
                   }
                   anvil.setRepairCost(cost);
                   // Перед установкой результата проверяем, все ли зачарования допустимы
                   if (!validateEnchantmentsForItem(event.getResult())) {
                        // Если обнаружено несовместимое зачарование – отменяем операцию
                        event.setResult(null);
                   }
              } else {
                   // Если результат равен null, создаём результат вручную
                   ItemStack book = isEnchantedBook(first) ? first : second;
                   ItemStack target = isEnchantedBook(first) ? second : first;
                   if (target != null && book != null) {
                         ItemStack result = target.clone();
                         if (book.hasItemMeta() && book.getItemMeta() instanceof EnchantmentStorageMeta) {
                              EnchantmentStorageMeta esm = (EnchantmentStorageMeta) book.getItemMeta();
                              for (Map.Entry<Enchantment, Integer> entry : esm.getStoredEnchants().entrySet()) {
                                   result.addUnsafeEnchantment(entry.getKey(), entry.getValue());
                              }
                         }
                         anvil.setRepairCost(MAX_REPAIR_COST);
                         // Проверяем итоговый предмет на допустимость зачарований.
                         if (!validateEnchantmentsForItem(result)) {
                               // Если найдено неподходящее зачарование, результат отменяется (будет "пустота")
                               event.setResult(null);
                         } else {
                               event.setResult(result);
                         }
                   }
              }
              return;
         }
         
         // Для остальных предметов: ограничиваем стоимость, если она выше MAX_REPAIR_COST.
         if (anvil.getRepairCost() > MAX_REPAIR_COST) {
              anvil.setRepairCost(MAX_REPAIR_COST);
         }
    }
    
    private boolean isEnchantedBook(ItemStack item) {
         return item != null && item.getType() == Material.ENCHANTED_BOOK;
    }
    
    /**
     * Проходит по всем зачарованиям итогового предмета и возвращает false,
     * если обнаруживается хоть одно, которое не предназначено для данного предмета.
     */
    private boolean validateEnchantmentsForItem(ItemStack item) {
         if (item == null) return true;
         for (Enchantment enchant : item.getEnchantments().keySet()) {
             if (!enchant.canEnchantItem(item)) {
                 return false;
             }
         }
         return true;
    }
}